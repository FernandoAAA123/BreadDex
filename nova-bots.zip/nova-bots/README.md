# Nova Bots — Railway Runner

Runner genérico que corre automáticamente todos los bots configurados en Nova Studio, 24/7.

## Cómo funciona

El runner es completamente genérico — no tiene lógica hardcodeada por tipo de bot. En cambio, cada bot en Firebase incluye un campo `runtimeCode` con el JS que define su comportamiento. Railway simplemente lo ejecuta.

```
Nova Studio (browser)
  └─ Crea/edita bot → guarda en Firebase (botdata/bots/{id})
       └─ incluye runtimeCode generado automáticamente

Railway (servidor)
  └─ Escucha botdata/bots/ en tiempo real
       ├─ child_added   → lanza el bot
       ├─ child_changed → reinicia el bot con nueva config
       └─ child_removed → detiene el bot
```

Cada `runtimeCode` recibe un objeto `ctx` con todas las herramientas necesarias:

| Función | Descripción |
|---------|-------------|
| `ctx.sendMsg(channelId, content)` | Envía un mensaje al canal |
| `ctx.listenChannel(channelId, callback)` | Escucha mensajes nuevos |
| `ctx.pickItem(items)` | Elige un elemento al azar (con peso) |
| `ctx.saveCapture(userId, item, num, name)` | Guarda una captura en Firebase |
| `ctx.sendCollection(channelId, userId, name)` | Envía la colección de un usuario |
| `ctx.scheduleInterval(minutes, callback)` | Ejecuta algo periódicamente (con ±15% jitter) |
| `ctx.dbGet(path)` | Lee un nodo de Firebase |
| `ctx.dbSet(path, value)` | Escribe en Firebase |
| `ctx.dbListen(path, callback)` | Escucha cambios en un nodo |
| `ctx.setPresence(customStatus)` | Marca el bot como online en Nova |
| `ctx.log(level, msg)` | Log con prefijo del bot (`info`, `warn`, `error`) |
| `ctx.stop()` | Detiene este bot |
| `ctx.bot` | Objeto con la config completa del bot |

## Tipos de bot soportados

Todos los bots creados desde Nova Studio incluyen `runtimeCode` automáticamente:

- **Bienvenida** — saluda a nuevos miembros
- **Dex genérico** — spawn automático, `/catch [nombre]`
- **Search** — `/img`, `/search`, `/yt`
- **Plugins** — si el plugin define `window.NOVA_BOT.runtimeCode`, Railway también lo corre

Los bots de tipo `external` (URL) no tienen `runtimeCode` — se abren en nueva pestaña y no corren en Railway.

## Estructura del repo

```
nova-bots/
  index.js      ← runner genérico (único archivo de lógica)
  package.json
  README.md
```

## Setup en Railway

### 1. Obtener el Service Account de Firebase

1. [Firebase Console](https://console.firebase.google.com) → tu proyecto → ⚙️ Configuración del proyecto → Cuentas de servicio
2. **Generar nueva clave privada** → descarga el JSON

### 2. Crear repo en GitHub

Crea un repo nuevo (ej. `nova-bots`) y sube `index.js`, `package.json` y `README.md`.

### 3. Crear servicio en Railway

1. [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**
2. Selecciona tu repo `nova-bots`
3. Railway detecta `package.json` y usa `npm start` solo

### 4. Añadir variable de entorno

Railway → tu servicio → **Variables** → añade:

```
FIREBASE_SERVICE_ACCOUNT = {contenido completo del JSON}
```

Pega el JSON entero como valor. Railway lo acepta aunque tenga saltos de línea.

### 5. Deploy

Railway despliega automáticamente. En los logs verás:

```
Nova Bots runner iniciado.
[bot_dex_xxx] Iniciando "MiDex" (dex)...
[bot_dex_xxx] OK
```

A partir de aquí, cada vez que crees o edites un bot en Nova Studio, Railway lo detecta y lo lanza/reinicia solo. No hay que tocar Railway manualmente.

## Crear un plugin compatible con Railway

Si quieres que tu plugin corra 24/7, añade `runtimeCode` a `window.NOVA_BOT`:

```js
window.NOVA_BOT = {
  id: 'mi-plugin',
  name: 'Mi Plugin',
  version: '1.0',
  icon: '🤖',
  color: '#7c3aed',
  description: 'Descripción del plugin.',
  commands: ['/cmd'],
  configFields: [...],

  // JS que Railway ejecutará — recibe ctx con todas las herramientas
  runtimeCode: `
    const channels = Object.values(ctx.bot.config.channels || {}).filter(Boolean);
    ctx.setPresence('🤖 Activo');
    channels.forEach(channelId => {
      ctx.listenChannel(channelId, async msg => {
        const txt = (msg.content || '').trim().toLowerCase();
        if (txt === '/cmd') {
          await ctx.sendMsg(channelId, '¡Hola desde el plugin!');
        }
      });
    });
  `
};
```

Cuando el usuario configure y guarde el plugin en Nova Studio, el `runtimeCode` se sube a Firebase y Railway lo lanza automáticamente.

## Variable de entorno requerida

| Variable | Descripción |
|----------|-------------|
| `FIREBASE_SERVICE_ACCOUNT` | JSON completo del service account de Firebase |
